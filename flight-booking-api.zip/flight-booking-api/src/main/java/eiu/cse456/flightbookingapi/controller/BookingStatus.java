package eiu.cse456.flightbookingapi.controller;

public enum BookingStatus {
    ON_BOOKING, START, END
}
