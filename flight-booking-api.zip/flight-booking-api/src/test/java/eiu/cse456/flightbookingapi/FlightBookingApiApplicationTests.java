package eiu.cse456.flightbookingapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightBookingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
